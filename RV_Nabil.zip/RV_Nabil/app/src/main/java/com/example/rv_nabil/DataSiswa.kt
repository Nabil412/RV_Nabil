package com.example.rv_nabil

data class DataSiswa (

    var nis: String,
    var nama: String,
    var jekel: String

)